import { Box,Flex,Image,Text } from '@chakra-ui/react'
import React from 'react'
import FundFact from './FundFact'
import HeroSection from './HeroSection'

const AboutusMain = () => {
  return (
    <>
    
   <Box bg="white" maxW={"1835px"} w="100%" mx="auto" px="20px" >
 <HeroSection
 bgColor="#5CFF15"
 Text1="About"
 Text2="us"
 Description="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per conubia nostra"
 />
 <Box maxW={"1417px"} w='100%' ml="auto">
    <Flex gap='32px' mb='99px'>
        <Box w="50%">
        <Text
            
            color="#000000"
            fontSize="24px"
            fontWeight="500"
            lineHeight={"44px"}
            mb="20px"
          >
      Forem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Curabitur tempus urna at turpis condimentum lobortis. Ut commodo efficitur neque. Ut diam quam, semper iaculis condimentum ac, vestibulum eu nisl.
          </Text>
          <Text
            
            color="#000000"
            fontSize="24px"
            fontWeight="500"
            lineHeight={"44px"}
          >
      Forem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent.
          </Text>
        </Box>
        <Box w="50%">
            <Image src="https://cdn.enochdev.com/enki/imagcard1.png"></Image>
        </Box>
    </Flex>
    

 </Box>
 <Box maxW={"1417px"} w='100%' mr="auto">
    <Flex gap='32px' mb='99px'>
    <Box w="50%">
            <Image src="https://cdn.enochdev.com/enki/imagcard1.png"></Image>
        </Box>
        <Box w="50%">
        <Text
            
            color="#000000"
            fontSize="24px"
            fontWeight="500"
            lineHeight={"44px"}
            mb="20px"
          >
      Forem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Curabitur tempus urna at turpis condimentum lobortis. Ut commodo efficitur neque. Ut diam quam, semper iaculis condimentum ac, vestibulum eu nisl.
          </Text>
          <Text
            
            color="#000000"
            fontSize="24px"
            fontWeight="500"
            lineHeight={"44px"}
          >
      Forem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent.
          </Text>
        </Box>
        
    </Flex>
    

 </Box>
   </Box>
   <Box pb="100px">
   <FundFact/>
   </Box>
 
   </>
  )
}

export default AboutusMain